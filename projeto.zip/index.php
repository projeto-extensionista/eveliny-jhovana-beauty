<?php 

include('routes.php');
include('template.php');