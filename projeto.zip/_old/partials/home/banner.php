<!-- Banner -->
 
<section>
    <div class="container">
        <div>
            <h1>Lorem Ipsum Dolor Sit Amet</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium  mauris quis dui porta vehicula. Nam turpis nisl, scelerisque quis  molestie id, fringilla id erat. Etiam in est non.</p>
            <div>
                <a href="#" target="_self">Lorem ipsum</a>
                <a href="#" target="_self">
                    <img src="assets/icons/icon-whatsapp.png" alt="" width="32" height="32">
                </a>
                <a href="#" target="_self">
                    <img src="assets/icons/icon-instagram.png" alt="" width="32" height="32">
                </a>
                <a href="#" target="_self">
                    <img src="assets/icons/icon-facebook.png" alt="" width="32" height="32">
                </a>
            </div>
        </div>
    </div>
</section>

<!-- / -->

