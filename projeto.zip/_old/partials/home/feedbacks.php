<?php 

// NÃO ABRA O LINK ABAIXO!!!!!
// TEM LIMITE MENSAL DE CONSULTAS E SE PASSAR VAI GERAR COBRANÇA
// FAÇA APENAS O DESIGN DA SEÇÃO (COM DADOS GENÉRICOS MESMO), DEPOIS VOU CONFIGURAR PRA PUXAR UMA VEZ POR DIA, PRA NAO ULTRAPASSAR O LIMITE
// https://mybusiness.googleapis.com/v4/accounts/15279221835961523423/locations/ChIJuXAGHg42tJQRMMqZ85AnWdk/reviews

?>

<!-- Banner -->

<section>
    <div class="container">
        <h1>Feedbacks</h1>
        <div>
            <article>
                <div>
                    <figure>
                        <img src="assets/img/temp-person.png" alt="" width="72" height="72">
                    </figure>
                    <div>
                        <h5>Diogo</h5>
                        <div>
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                        </div>
                    </div>
                </div>
            </article>
            <article>
                <div>
                    <figure>
                        <img src="assets/img/temp-person.png" alt="" width="72" height="72">
                    </figure>
                    <div>
                        <h5>Diogo</h5>
                        <div>
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                        </div>
                    </div>
                </div>
            </article>
            <article>
                <div>
                    <figure>
                        <img src="assets/img/temp-person.png" alt="" width="72" height="72">
                    </figure>
                    <div>
                        <h5>Diogo</h5>
                        <div>
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                            <img src="assets/icons/icon-star.png" alt="" width="16" height="16">
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</section>

<!-- / -->

