<footer>
    <div class="container">
        <div>
            <span>© 2025 Eveliny Jhovana Beauty - All rights reserved</span>
        </div>
    </div>
</footer>