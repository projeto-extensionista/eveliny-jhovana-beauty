<header>
    <div class="container">
        <a href="/">
            <img src="" alt="" width="" height="">
        </a>
        <a href="#" target="_self">Agendamento</a>
        <button>
            <div></div>
            <div></div>
            <div></div>
        </button>
        <nav>
            <ul>
                <li>
                    <a href="#" target="_self">Lorem ipsum</a>
                </li>
                <li>
                    <a href="#" target="_self">Lorem ipsum</a>
                </li>
                <li>
                    <a href="#" target="_self">Lorem ipsum</a>
                </li>
                <li>
                    <a href="#" target="_self">Lorem ipsum</a>
                </li>
            </ul>
        </nav>
    </div>
</header>